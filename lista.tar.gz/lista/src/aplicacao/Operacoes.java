
package aplicacao;

import java.util.ArrayList;


public class Operacoes {
    
    //adicionando uma tarefa (t) na lista
    public boolean adicionar (Tarefa t, ArrayList<Tarefa> lista){
    
         return true;
    }
    
    
    
    
    //deletando uma tarefa (t)  da lista (sobreescever)
    
    public boolean editar (Tarefa t,int i, ArrayList<Tarefa> lista){
    
    
    return true;
    
    }
    
    
    
    //editando uma tarefa (t) da lista 
    
    
    
    
    
    
    
}
