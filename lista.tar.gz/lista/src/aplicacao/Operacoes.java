package aplicacao;

import java.util.ArrayList;

public class Operacoes {

    //adicionando uma tarefa (t) na lista
    public boolean adicionar(Tarefa t, ArrayList<Tarefa> lista) {
        return lista.add(t);

    }

    //deletando uma tarefa (t)  da lista (sobreescever)
    public boolean excluir(Tarefa t, ArrayList<Tarefa> lista) {

        return true;
    }

    //editando uma tarefa (t) da lista 
    public boolean editar(Tarefa t, int i, ArrayList<Tarefa> lista) {

        return true;
    }

}
