package aplicacao;

import java.util.ArrayList;

public class Operacoes {

    //adicionando uma tarefa (t) na lista
    public boolean adicionar(Tarefa t, ArrayList<Tarefa> lista) {
        return lista.add(t);

    }

    //deletando uma tarefa (t)  da lista (sobreescever)
    public boolean excluirTask(int idTarefa, ArrayList<Tarefa> lista) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getId() == idTarefa) {
                lista.remove(i);
                return true;
            }
        }
        return false;
    }


    // editando uma tarefa (t) da lista 
    public boolean editar(Tarefa t, int i, ArrayList<Tarefa> lista) {
        if (i >= 0 && i < lista.size()) {
            lista.set(i, t); // substitui a tarefa no índice 'i' pela nova 't'
            return true;
        }
        return false; // índice inválido
    }
}
