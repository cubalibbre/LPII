/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aplicacao;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class Transaction {

    public boolean excluirTask(int idTarefa, ArrayList<Tarefa> lista) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getId() == idTarefa) {
                lista.remove(i);
                return true;
            }
        }
        return false;
    }
}
