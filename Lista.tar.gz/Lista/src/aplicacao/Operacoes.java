
package aplicacao;

import java.util.ArrayList;
import java.util.Iterator;


public class Operacoes {    
    //adicionando uma tarefa (t) no ArrayList lista de tarefas
    public boolean adicionar(Tarefa t, ArrayList<Tarefa> lista){        
        return lista.add(t);        
    }    
    //deletando uma tarefa (t) da lista
    public boolean excluir(int id, ArrayList<Tarefa> lista){
        boolean removido = false;
        Iterator it = lista.iterator();
        while (it.hasNext()) {
            Tarefa t = (Tarefa) it.next();
            if (t.getId() == id) {
                it.remove();
                removido = true;
                break;
            }
            
        }
        return removido;
             
    }        
    //editando a tarefa (t) do indice (i) da lista
    public boolean editar(int id, ArrayList<Tarefa> lista, Tarefa t){
        boolean editado = false;
        for (int j = 0; j < lista.size(); j++) {
            if (lista.get(j).getId() == id) {
                lista.set(j, t);
                editado = true;
                break;
            }
        }
        return editado;        
    }    
}
