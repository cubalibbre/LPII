package aplicacao;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TelaDeCadastro extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(TelaDeCadastro.class.getName());

    int id; //nº da tarefa   
    ArrayList<Tarefa> listaTask = new ArrayList<>(); //lista de tarefas    
    DefaultTableModel dtm; //tabela

    public TelaDeCadastro() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtTitulo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtData = new javax.swing.JFormattedTextField();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        textDesc = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        cmbNivel = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblTask = new javax.swing.JTable();
        btAdd = new javax.swing.JButton();
        btDel = new javax.swing.JButton();
        btEdit = new javax.swing.JButton();
        btClear = new javax.swing.JButton();
        btClose = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle(":: CADASTRO DE TAREFAS ::");

        jPanel1.setBorder(new javax.swing.border.MatteBorder(null));

        jLabel1.setText("TÍTULO");

        jLabel2.setText("DATA LIMITE");

        txtData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDataActionPerformed(evt);
            }
        });

        jLabel3.setText("DESCRIÇÃO");

        textDesc.setColumns(20);
        textDesc.setRows(5);
        textDesc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                textDescMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(textDesc);

        jLabel4.setText("NÍVEL");

        cmbNivel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Fácil", "Intermediário", "Difícil" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtData, javax.swing.GroupLayout.DEFAULT_SIZE, 272, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(cmbNivel, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2)
                    .addComponent(txtTitulo))
                .addContainerGap(42, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtData, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(cmbNivel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        tblTask.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "TÍTULO", "DESCRIÇÃO", "NÍVEL", "DATA LIMITE"
            }
        ));
        tblTask.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblTaskMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblTask);

        btAdd.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        btAdd.setText("ADD");
        btAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddActionPerformed(evt);
            }
        });

        btDel.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        btDel.setText("DEL");
        btDel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDelActionPerformed(evt);
            }
        });

        btEdit.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        btEdit.setText("EDIT");
        btEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEditActionPerformed(evt);
            }
        });

        btClear.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        btClear.setText("CLEAR");
        btClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btClearActionPerformed(evt);
            }
        });

        btClose.setFont(new java.awt.Font("DejaVu Sans", 1, 12)); // NOI18N
        btClose.setText("CLOSE");
        btClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCloseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane1)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addComponent(btAdd)
                        .addGap(35, 35, 35)
                        .addComponent(btDel)
                        .addGap(53, 53, 53)
                        .addComponent(btEdit)
                        .addGap(43, 43, 43)
                        .addComponent(btClear)
                        .addGap(30, 30, 30)
                        .addComponent(btClose)))
                .addContainerGap(54, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btAdd)
                    .addComponent(btDel)
                    .addComponent(btEdit)
                    .addComponent(btClear)
                    .addComponent(btClose))
                .addGap(21, 21, 21))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDataActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDataActionPerformed

    private void btAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddActionPerformed
        //capturando as informações digitadas pelo usuário 
        String tit = txtTitulo.getText();
        String dta = txtData.getText();
        int niv = cmbNivel.getSelectedIndex();
        String desc = textDesc.getText();
        //criando a tarefa (objeto tarefa)
        Tarefa t = new Tarefa(tit, desc, dta, ++id, niv);
        //criando o objeto Operacoes
        Operacoes op = new Operacoes();
        if (op.adicionar(t, listaTask)) {
            //JOptionPane.showMessageDialog(rootPane, "SUCESSO!!!");
            showTask();
            limpar();
        } else {
            JOptionPane.showMessageDialog(rootPane, "FALHA!!!");
        }

    }//GEN-LAST:event_btAddActionPerformed

    private void btCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCloseActionPerformed
        System.exit(0);//comando p/ encerrar programa        
    }//GEN-LAST:event_btCloseActionPerformed

    private void btClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btClearActionPerformed
        limpar();
    }//GEN-LAST:event_btClearActionPerformed

    private void tblTaskMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblTaskMouseClicked
        // getSelectedRow() => seleciona a linha da atebal q o suário clicou
        if (tblTask.getSelectedRow() != -1) {
            txtTitulo.setText(
                    tblTask.getValueAt(tblTask.getSelectedRow(), 1).toString());
            textDesc.setText(
                    tblTask.getValueAt(tblTask.getSelectedRow(), 2).toString());
            cmbNivel.setSelectedIndex((int) tblTask.getValueAt(tblTask.getSelectedRow(), 3));
            txtData.setText(tblTask.getValueAt(tblTask.getSelectedRow(), 4).toString());
        }

    }//GEN-LAST:event_tblTaskMouseClicked

    private void textDescMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textDescMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_textDescMouseClicked

    private void btDelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDelActionPerformed
        if (tblTask.getSelectedRow() != -1) {
            int id = (int) tblTask.getValueAt(tblTask.getSelectedRow(), 0);
            Operacoes op = new Operacoes();
            if (op.excluir(id, listaTask)) {
                dtm.removeRow(tblTask.getSelectedRow());
            } else {
                JOptionPane.showMessageDialog(rootPane, evt);
            }

        } else {
            JOptionPane.showMessageDialog(rootPane, evt);
        }
        showTask();
        limpar();
    }//GEN-LAST:event_btDelActionPerformed

    private void btEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEditActionPerformed
        if (tblTask.getSelectedRow() != 1) {
            String titulo = txtTitulo.getText();
            int nivel = cmbNivel.getSelectedIndex();
            String data = txtData.getText();
            String descricao = textDesc.getText();
            int id = (int) tblTask.getValueAt(tblTask.getSelectedRow(), 0);
            Tarefa tAtual = new Tarefa(titulo, descricao, data, id, nivel);
            Operacoes op = new Operacoes();
            if (op.editar(id, listaTask, tAtual)) {
                showTask();
                limpar();
            }
        }
    }//GEN-LAST:event_btEditActionPerformed


//metodo que limpa os campos do formulário
    private void limpar() {
        txtTitulo.setText("");
        txtData.setText("");
        textDesc.setText("");
        cmbNivel.setSelectedIndex(0);
    }
   

    //método que mostra as tarefas adicionadas na lista
    private void showTask() {
        dtm = (DefaultTableModel) tblTask.getModel();
        dtm.setNumRows(0);
        for (int i = 0; i < listaTask.size(); i++) {
            dtm.addRow(new Object[]{
                listaTask.get(i).getId(),
                listaTask.get(i).getTitulo(),
                listaTask.get(i).getDescricao(),
                listaTask.get(i).getNivel(),
                listaTask.get(i).getDataLimite()
            });
        }//fechamento do for
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new TelaDeCadastro().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAdd;
    private javax.swing.JButton btClear;
    private javax.swing.JButton btClose;
    private javax.swing.JButton btDel;
    private javax.swing.JButton btEdit;
    private javax.swing.JComboBox<String> cmbNivel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblTask;
    private javax.swing.JTextArea textDesc;
    private javax.swing.JFormattedTextField txtData;
    private javax.swing.JTextField txtTitulo;
    // End of variables declaration//GEN-END:variables
}
