
package aplicacao;

public class Tarefa {
    
    private String titulo, descricao, datalimite;
    private int id, nivel;

    public Tarefa() {
    } 

    public Tarefa(String titulo, String descricao, String datalimite, int id, int nivel) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.datalimite = datalimite;
        this.id = id;
        this.nivel = nivel;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getDatalimite() {
        return datalimite;
    }

    public void setDatalimite(String datalimite) {
        this.datalimite = datalimite;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    @Override
    public String toString() {
        return "Tarefa{" + "titulo=" + titulo + ", descricao=" + descricao + ", datalimite=" + datalimite + ", id=" + id + ", nivel=" + nivel + '}';
    }
    
    
}
