
package aplicacao;


public class Lista {

  
    public static void main(String[] args) {
        String [] diasdasemana = {"dog","seg","ter","qua","qui","sex","sab"};
        
        Tarefa [] listadetarefas = new Tarefa [5];        
         
        //String [] diasdasemana2 = new String [7];
        
        for (int i = 0; i < 7; i++) {
            System.out.println("");
            
        }
        
    }
    
}
