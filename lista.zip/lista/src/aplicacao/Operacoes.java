package aplicacao;

import java.util.ArrayList;

public class Operacoes {

    //adicionando uma tarefa (t) na lista
    public boolean adicionar(Tarefa t, ArrayList<Tarefa> lista) {
        return lista.add(t);

    }

    //deletando uma tarefa (t)  da lista (sobreescever)
    public boolean excluir(Tarefa t, ArrayList<Tarefa> lista) {

        return true;
    }

    //editando uma tarefa (t) da lista 
    public boolean editar(Tarefa t, int id, ArrayList<Tarefa> lista) {
        boolean editado = false;
        //loop de incrimentando da lista 
        for (int j = 0; j < lista.size(); j++) {
           
            if (lista.get(j).getId() == id) {
               lista.set(j, t); // edita
               editado = true;
               break;
            }
            
        }
        
        
        return editado;
    }

}
