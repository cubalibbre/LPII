package socketsudp;

import java.io.IOException;
import java.net.*;

public class Servidor {


    public static void main(String[] args) {
        
        try {
            DatagramSocket ds = new DatagramSocket(8080);
            System.out.println("Servidor operando na porta 8080");
            byte[] recDados = new byte[512];
            byte[] envDados = new byte[512];
            
            DatagramPacket dpRD = new DatagramPacket(recDados, recDados.length);
            ds.receive(dpRD); //recebendo os dados do cliente
            
            String msg = new String(dpRD.getData()); //conteudo da mensagem
            InetAddress ip = dpRD.getAddress(); //o endereço da maquina que enviou a mensagem
            int porta = dpRD.getPort(); //porta pelo qual entrou a msg
            
            System.out.println("Mensagem do cliente: " + msg);
            System.out.println("Endereço IP........." + ip.toString());
            System.out.println("Porta............... " + porta);
            
            //montando pacote para envio de dados
            envDados = msg.toUpperCase().getBytes();
            DatagramPacket dpED = new DatagramPacket(envDados, envDados.length, ip, porta);
            
            ds.send(dpED);
                    
        } catch (IOException e) {
            System.out.println("Exceção: " + e);
            
        }
    }
    
}
