package socketsudp;

import java.io.IOException;
import java.net.*;
import java.util.Arrays;

public class Cliente {

    public static void main(String[] args){
        
        try{
            
            DatagramSocket dsCliente = new DatagramSocket();
            
            InetAddress ip = InetAddress.getByName("localhost");
            
            byte[] recDados = new byte[512];
            byte[] envDados = new byte[512];
            
            String msg = "salve cria";
            envDados = msg.getBytes();
            //monta o pacote a ser enviado, passando a msg e seu tamanho, 
            //o endereço ip e a porta em que o servidor esta executando
            DatagramPacket dpED = new DatagramPacket(envDados, envDados.length, 
                    ip, 8080);
            dsCliente.send(dpED); //cliente enviando pacote
            
            DatagramPacket dpRD = new DatagramPacket(recDados, recDados.length);
            dsCliente.receive(dpRD);
            
            String msgM = new String(dpRD.getData());
            System.out.println(msgM);
            dsCliente.close();
            
        }catch (IOException e){
            System.out.println("Exceção: " + e);
        }
        
        
    }
    
}
