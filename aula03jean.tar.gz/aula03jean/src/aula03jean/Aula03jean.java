
package aula03jean;

import java.util.Scanner;



public class Aula03jean {


  
    public static void main(String[] args) {
        
        //CRINADO O OBJETO "INPUT" PARA LEITURA DE DADOS
        Scanner entrada  = new Scanner(System.in);
        
        
       // System.out.println("Digite nota 1:");
        //double n1 = entrada.nextDouble(); // CAPTURANDO N1
        
        // System.out.println("Digite nota 2:");
        //double n2 = entrada.nextDouble(); // CAPTURANDO N2
        
        // System.out.println("Digite nota 3:");
        //ouble n3 = entrada.nextDouble(); // CAPTURANDO N3
         
  
       //op representa a "a ponte" entre Aula03 e operacoes 
        operacoes op2 = new operacoes(200, 0.05, 12);
        
        //double media = op.media(n1, n2, n3);
        
        
        System.out.println("montante" + op2.montante() );//

         
       
    }
    
}
