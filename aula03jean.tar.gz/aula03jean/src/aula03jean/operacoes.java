
package aula03jean;


public class operacoes {
    
     private double c, i; //c: capital inicial e i: taxa de juros
     private int n; // n: periodo em meses
        

        
    //toda classe em java tem o metodo construtor visivel ou não.
    //metodo construtor, obrigatoriamente, tem o mesmo nome da classe
    //metodo construtor nao e nao pode ter tipo de dado de retorno (ex.:double,void)  
        
     

    public operacoes() {    
        
        
   
    }
    
    public operacoes(double c, double i, int n ) {
        
        this.c= c;
        this.i= i;
        this.n= n;
        
        //System.out.println("juros = " +  c * i * n);

    }
    public double montante (){
        double j = c*i*n;
        return (c + j);   
        
    }
    public double media (double n1, double n2, double n3){
        return (n1+n2+n3)/3;
    
    
    
   
    }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    
    
    
        
        
        
        
        
    
    }
    

    //public double media(double n1, double n2, double n3) { 
        
        //return (n1+n2+n3)/3;
        
    
    
    
    
 
    }   
    
}
