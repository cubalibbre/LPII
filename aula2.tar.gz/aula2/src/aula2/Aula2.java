
package aula2;

import java.util.Scanner;


public class Aula2 {

   
    public static void main(String[] args) { //void nãoretorna valor (return não funciona)
        System.out.println("Projeto Aula 2");//comando de saída
        //criando onbejto in do tipo scanner
        Scanner in = new Scanner (System.in);//comando de entrada chamar next,  
        
        
        //System.out.println("Entre com o nome:");
        //String nome = in.next();//objeto in chamando o método next()
        //System.out.println("Entre coom o nome de Nascimento:");
        //int AnoDeNascimento = in.nextInt();//comando para chamar numero inteiro (int),next,int
        //System.out.println("olá" + nome + "sua idade em 2025 é:" +
        //        (2025 - AnoDeNascimento));
        
        System.out.println("Entre com o valor de x e y:");
        int x = in.nextInt();
        int y = in.nextInt();
        
        
        System.out.println (x + "+" + y + "=" + somaSimples (x, y ));
        Operacoes op = new Operacoes();//criei um objeto do tipo operacoes 
        System.out.println(x + "x" + y + "="
                                       +op.multSomaSimplesOP(x, y));


    }//fechamento do main
                  //tipo de dado de return 
    private static int somaSimples (int n1, int n2) { //(int n1, int n2 entrada
        
        int soma = 0;
        
        soma = n1 + n2;
        
        return soma;
        
 
    }
    
    
}//fim da classe Aula02
