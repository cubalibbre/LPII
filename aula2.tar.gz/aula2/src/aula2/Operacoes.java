
package aula2;


public class Operacoes {
    public int multSomaSimplesOP (int n1, int n2) { //(int n1, int n2 entrada
        
        int mult = 0;
        
        mult = n1 * n2;
        
        return mult;
        
    }
}
