package login;

import java.util.Scanner;


public class Login {


    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Insira o nome de usuário: ");
        String user = input.next();
        
        System.out.println("Insira a senha: ");
        int senha = input.nextInt();
        
        if (user.equals("IFBA") && senha==123456) {
            System.out.println("Acesso liberado!");
        }else{
            System.out.println("Acesso negado.");
        }
        
    }
    
}
