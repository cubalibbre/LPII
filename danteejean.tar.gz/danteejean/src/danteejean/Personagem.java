package danteejean;

public class Personagem {

    private String nome, nomeReal;
    private Superpoder[] poderes = new Superpoder[4];

    public Personagem(String nome, String nomeReal) {
        this.nome = nome;
        this.nomeReal = nomeReal;
    }

    public void adicionaSuperpoder(Superpoder sp) {
        for (int i = 0; i < 4; i++) {
            poderes[i] = sp;
        }
    }

    public int getPoderTotal() {
        int soma = 0;
        for (int i = 0; i < 4; i++) {
            soma += poderes[i].getCategoria();
        }
        return soma;
    }

}
