
package herança;


public class Funcionario extends Pessoa {
    private double salario;

    public Funcionario(double salario, String nome, String cpf) {
        super(nome, cpf);
        this.salario = salario;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    @Override
    public String toString() {
        String dados = super.toString();
        return dados + " \n contratado como Funcionario{" + "salario=" + salario + '}';
    }
    
}
