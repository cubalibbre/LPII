package escolajean;


public class Aluno {
   //atributos da classe aluno
   private String nome;
   private int  matricula;
   //construtor que recebe o nome e a matricula do aluno

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public Aluno(String nome, int matricula) {
        this.nome = nome;
        this.matricula = matricula;
    }

    @Override
    public String toString() {
        return "Aluno{" + "nome=" + nome + ", matricula=" + matricula + '}';
    }
  
    
}//4final da classe aluno
