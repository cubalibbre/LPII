
package escolajean;



public class Professor {
    private String nome;
    private String Area;

    public Professor(String nome, String Area) {
        this.Area = Area;
        this.nome = nome;
    }
   

    public String getNome() {
        return nome;
    }

    @Override
    public String toString() {
        return "Professor{" + "nome=" + nome + ", Area=" + Area + '}';
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getArea() {
        return Area;
    }

    public void setArea(String Area) {
        this.Area = Area;
    }
    
    
    
}
