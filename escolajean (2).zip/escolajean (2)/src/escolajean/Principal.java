
package escolajean;

public class Principal {

    public static void main(String[] args) {
        
        Professor p1 = new Professor("roberta", "informática");
        System.out.println(p1.toString());
        
       // System.out.println(p1.getNome().toUpperCase() +  " ,voce vai da aula hoje");//.toUpperCase() deixa em letra maiuscula
        
        
        Aluno a1 = new Aluno("jean", 12345);
        System.out.println(a1.toString());
       // System.out.println(a1.getNome().toUpperCase() +  " ,voce vai p/ aula hoje");//.toUpperCase() deixa em letra maiuscula
        //aspas para string
       
    }

    

    
}
