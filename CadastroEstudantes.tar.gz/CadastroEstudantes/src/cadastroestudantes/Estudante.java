package cadastroestudantes;


public class Estudante {
    private String nome;
    private int matricula,genero, curso;

    public int getCurso() {
        return curso;
    }

    public void setCurso(int curso) {
        this.curso = curso;
    }

    @Override
    public String toString() {
        return "Estudante{" + "nome=" + nome + ", curso= "+ curso + ", matricula=" + matricula + ", genero=" + genero + '}';
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }


    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public int getGenero() {
        return genero;
    }

    public void setGenero(int genero) {
        this.genero = genero;
    }

    public Estudante(String nome, String turma, int matricula, int genero) {
        this.nome = nome;
        this.curso = curso;
        this.matricula = matricula;
        this.genero = genero;
    }
}
