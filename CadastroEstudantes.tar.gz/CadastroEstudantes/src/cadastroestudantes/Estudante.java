package cadastroestudantes;


public class Estudante {
    private String nome, turma;
    private int matricula,genero;

    @Override
    public String toString() {
        return "Estudante{" + "nome=" + nome + ", turma=" + turma + ", matricula=" + matricula + ", genero=" + genero + '}';
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTurma() {
        return turma;
    }

    public void setTurma(String turma) {
        this.turma = turma;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public int getGenero() {
        return genero;
    }

    public void setGenero(int genero) {
        this.genero = genero;
    }

    public Estudante(String nome, String turma, int matricula, int genero) {
        this.nome = nome;
        this.turma = turma;
        this.matricula = matricula;
        this.idade = idade;
        this.genero = genero;
    }
}
