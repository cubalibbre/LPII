package cadastroestudantes;
import java.util.ArrayList;
import java.util.Iterator;

public class Operacoes {
    public boolean adicionar(Estudante e, ArrayList<Estudante> lista){
        return lista.add(e);
    }
    public boolean excluir(int matricula, ArrayList<Estudante> lista){
        boolean removido = false;
        Iterator it = lista.iterator();
        while (it.hasNext()){
            Estudante e = (Estudante) it.next();
            if(e.getMatricula() == matricula){
                it.remove();
                removido = true;
                break;
            }
        }
        return removido;
    }
    public boolean editar(int matricula,ArrayList<Estudante> lista, Estudante e){
        boolean editado = false;
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getMatricula() == matricula) {
                lista.set(matricula, e);
                editado = true;
                break;
            }
        }
     return editado;   
    }
}
/*ADRIAN REIS SANTANA,202319810018
ANA BEATRIZ AQUINO GAMBERONI VIANA,202319810010
DANTE BORGES BANEGA,202319810004
Jean Freitas Santos,202319810035
Júlya Souza Leal,202319810033
LARA SIMEÃO,202319810001
Foto de LUNA DOS SANTOS ALVAREZ,202319810003
MARIA EDUARDA FONTES AQUINO,202319810019
MARIA LUIZADRIAN REIS SANTANA,202319810018
ANA BEATRIZ AQUINO GAMBERONI VIANA,202319810010
DANTE BORGES BANEGA,202319810004
Jean Freitas Santos,202319810035
Júlya Souza Leal,202319810033
LARA SIMEÃO,202319810001
Foto de LUNA DOS SANTOS ALVAREZ,202319810003
MARIA EDUARDA FONTES AQUINO,202319810019
MARIA LUIZA NOGUEIRA DO CARMO SANTOS,202319810014
Marynna santos Marques,202319810028
NATHAN SANTANA SILVA,202319810016
NICOLLY PAIVA SANTOS,202319810002
THIFANNY DHARLAT DO ROSÁRIO PEREIRA,202319810012
Yohanna de Assis Nascimento,202219810020
A NOGUEIRA DO CARMO SANTOS,202319810014
Marynna santos Marques,202319810028
NATHAN SANTANA SILVA,202319810016
NICOLLY PAIVA SANTOS,202319810002
THIFANNY DHARLAT DO ROSÁRIO PEREIRA,202319810012
Yohanna de Assis Nascimento,202219810020
