
package cadastroestudantes;

public class CadastroEstudantes {


    public static void main(String[] args) {
        
    }
    
}
