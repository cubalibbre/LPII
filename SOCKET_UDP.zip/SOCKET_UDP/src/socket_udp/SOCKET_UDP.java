
package socket_udp;


public class SOCKET_UDP {

   
    public static void main(String[] args) {
        
    }
    
}
