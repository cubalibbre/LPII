package escola;


public class Professor {
    private String area, nome;

    
    
    public Professor (String area, String nome){
        this.area = area;
        this.nome = nome;
    }

    @Override
    public String toString() {
        return "Professor{" + "area=" + area + ", nome=" + nome + '}';
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
}
