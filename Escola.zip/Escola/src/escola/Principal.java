package escola;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {

//        Professor p1 = new Professor("Informática", "Roberta");
//        
//        System.out.println(p1.toString());
//        
//        System.out.println(p1.getNome() + " você vai dar aula hoje?");
//        
//        Aluno a1 = new Aluno("Dante", 12345);
//        
//        System.out.println(a1.toString());
//        
//        System.out.println(a1.getNome() + " você vai a escola hoje?");
        Scanner input = new Scanner(System.in);

        for (int i = 0; i < 2; i++) {
            System.out.println("Insira o nome do aluno: ");
            String nome = input.next();
            System.out.println("Insira o número de matricula do aluno: ");
            int matricula = input.nextInt();
            Aluno aluno = new Aluno(nome, matricula);
            
            System.out.println("Insira o nome do professor: ");
            String nomeProf = input.next();
            System.out.println("Insira a área de atuação do professor: ");
            String area = input.next();
            Professor prof = new Professor(nomeProf, area);
        
        }

    }

}
