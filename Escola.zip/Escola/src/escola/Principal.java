package escola;


public class Principal {
    
    

    public static void main(String[] args) {
        
        Professor p1 = new Professor("Informática", "Roberta");
        
        System.out.println(p1.toString());
        
        System.out.println(p1.getNome() + " você vai dar aula hoje?");
        
        Aluno a1 = new Aluno("Dante", 12345);
        
        System.out.println(a1.toString());
        
        System.out.println(a1.getNome() + " você vai a escola hoje?");
        
        
    }
    
}
