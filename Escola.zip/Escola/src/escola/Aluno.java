package escola;


public class Aluno {
    //atributos da classe aluno
    private String nome;
    private int matricula;

    
    //metodo construtor que recebe nome e matricula
    public Aluno(String nome, int matricula) {
        this.nome = nome;
        this.matricula = matricula;
    
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    @Override
    public String toString() {
        return "Aluno {" + "nome=" + nome + ", matricula=" + matricula + '}';
    }
    

    
    

     
                

    
    
    
    
    
}
