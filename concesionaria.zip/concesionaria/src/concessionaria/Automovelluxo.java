
package concessionaria;


public class Automovelluxo extends Automovelbasico {
    
    boolean direcaoHidraulica, cambioAutomatico, travasEletricas;

    public Automovelluxo(boolean direcaoHidraulica, boolean cambioAutomatico, boolean travasEletricas, boolean retrovisorPassageiro, boolean limpadorTraseiro, boolean radio, String modelo, String cor, int combustivel) {
        super(retrovisorPassageiro, limpadorTraseiro, radio, modelo, cor, combustivel);
        this.direcaoHidraulica = direcaoHidraulica;
        this.cambioAutomatico = cambioAutomatico;
        this.travasEletricas = travasEletricas;
    }

    public Automovelluxo(boolean retrovisorPassageiro, boolean limpadorTraseiro, boolean radio, String modelo, String cor, int combustivel){
        super(null, null, 0);
    }
    
    
   
   
   
 
}
