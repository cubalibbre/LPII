
package concessionaria;

public class Automovelbasico extends Automovel {
   
    boolean retrovisorPassageiro, limpadorTraseiro, radio;

    public Automovelbasico(boolean retrovisorPassageiro, boolean limpadorTraseiro, boolean radio, String modelo, String cor, int combustivel) {
        super(modelo, cor, combustivel);
        this.retrovisorPassageiro = retrovisorPassageiro;
        this.limpadorTraseiro = limpadorTraseiro;
        this.radio = radio;
    }
    public Automovelbasico(String modelo, String cor, int combustivel){
        super (modelo, cor, combustivel);
        retrovisorPassageiro = true;
        limpadorTraseiro = true;
        radio = true;
     
    }
    @Override
    public double quantocusta(){
       double preco = super.quantocusta();
       
       if(retrovisorPassageiro){
           preco += 280;
       }  
       if (limpadorTraseiro){
           preco += 190;
      
       }
       if (radio){
           preco += 320;
       }
       return preco; 
        
    }
    
}
