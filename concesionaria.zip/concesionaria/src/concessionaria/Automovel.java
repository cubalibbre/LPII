

package concessionaria;


public class Automovel {
    String modelo, cor;
    int combustivel;

    public Automovel(String modelo, String cor, int combustivel) {
        this.modelo = modelo;
        this.cor = cor;
        this.combustivel = combustivel;
    }
    
    public double quantocusta(){
        double preco = 0;
        switch (combustivel){
            case 1:
             preco = 20000;
             break;
             
             case 2:
             preco = 19520;
             break;
             
             case 3:
             preco = 25000;
             break;
             
             case 4:
             preco = 22000;
             break;
             default:
                 break;
    
            
        }
        return preco;
        
        
    }
    
    
}
