package projetolp1;

public class Produto {
    
    private String nome, qtd, prc;

    public Produto(String nome, String qtd, String prc) {
        this.nome = nome;
        this.qtd = qtd;
        this.prc = prc;
    }

    public String getnome() {
        return nome;
    }

    public void setnome(String nome) {
        this.nome = nome;
    }

    public String getqtd() {
        return qtd;
    }

    public void setqtd(String qtd) {
        this.qtd = qtd;
    }

    public String getprc() {
        return prc;
    }

    public void setprc(String prc) {
        this.prc = prc;
    }

    @Override
    public String toString() {
        return "Produto{" + "nome=" + nome + ", qtd=" + qtd + ", prc=" + prc + '}';
    }
    
   
}
