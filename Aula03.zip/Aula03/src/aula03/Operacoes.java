package aula03;

public class Operacoes {

    /* "public Operacoes(){}" é o método contrutor, tem o mesmo nome da classe
        Este método não deve ter tipo de dado de retorno (int, void, etc)
     */
    public Operacoes() {

    }

    public double media(double n1, double n2, double n3) {

        return (n1 + n2 + n3) / 3;

    }

    //criação de um metodo pra calculo de juros mensais simples
    private double c, i; //capital inicial e taxa mensal de juros
    private int t; //periodo em meses
    //as variáveis c, i e t, criadas em Operacoes, são atributos da classe
    
    public Operacoes(double c, double i, int t) {
        
        /* pegando o valor que entrou neste metodo e colocando nos atributos
          da classe */
        
        this.c= c;
        this.i= i;
        this.t= t;
        
    }
    
    public double montanteComposto(){
        double qtd = c * Math.pow(( 1 + i ),t);
        return (c + qtd);       
    }
    
    public double montante(){
        double j = c * i * t;
        return (c + j);
    }
}
