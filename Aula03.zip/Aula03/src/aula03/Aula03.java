package aula03;

import java.util.Scanner;

public class Aula03 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Insira a primeira nota:");
        double n1 = input.nextDouble();

        System.out.println("Insira a segunda nota:");
        double n2 = input.nextDouble();

        System.out.println("Insira a terceira nota:");
        double n3 = input.nextDouble();
        
        Operacoes op = new Operacoes(); //a3 representa a ligação entre a classe Aula03 e a classe Operacoes
        
        double media = op.media(n1, n2, n3);

        System.out.println("A média final é " + media);
        
        Operacoes op2 = new Operacoes(2000, 0.05, 24);
        System.out.println("O montante é: " + op2.montante());
        
        
    }

}
