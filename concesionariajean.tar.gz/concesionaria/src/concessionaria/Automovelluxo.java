
package concessionaria;


public class Automovelluxo extends Automovelbasico {
    
    boolean direcaoHidraulica, cambioAutomatico, travasEletricas;

    public Automovelluxo(boolean direcaoHidraulica, boolean cambioAutomatico, boolean travasEletricas, boolean retrovisorPassageiro, boolean limpadorTraseiro, boolean radio, String modelo, String cor, int combustivel) {
        super(retrovisorPassageiro, limpadorTraseiro, radio, modelo, cor, combustivel);
        this.direcaoHidraulica = direcaoHidraulica;
        this.cambioAutomatico = cambioAutomatico;
        this.travasEletricas = travasEletricas;
    }

    public Automovelluxo(boolean direcaoHidraulica, boolean cambioAutomatico, boolean travasEletricas, String modelo, String cor, int combustivel) {
        super(modelo, cor, combustivel);
        this.direcaoHidraulica = true;
        this.cambioAutomatico = true;
        this.travasEletricas = true;
    }

    public double quantocusta(){
        
       double preco = super.quantocusta();
       
       if(direcaoHidraulica){
           preco += 3340;
       }  
       if (cambioAutomatico){
           preco += 1650;
      
       }
       if (travasEletricas){
           preco += 2190;
       }
        return preco;
      
    }
   
 
}
