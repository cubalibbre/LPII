
package concessionaria;


public class Demoauto {

    
    public static void main(String[] args) {
        
        Automovel auto = new Automovel ("hilux","preto", 1);
        System.out.println("O preço do " + auto.modelo + "é R$" + auto.quantocusta());
        
        Automovelbasico autobas1 = new Automovelbasico("gol", "azul", 1);
        System.out.println("O preço do" + autobas1.modelo + "é R$" + autobas1.quantocusta());
        
        Automovelbasico autobas2 = new Automovelbasico(true,false,false, "Palio","branco", 1);
        System.out.println("O preço do" + autobas2.modelo + "é R$" + autobas2.quantocusta());
        
        Automovelluxo autoluxo1 = new Automovelluxo(true,true,true,true,true,true,"Corrola","vemelho",3);
        System.out.println("O preço do" + autoluxo1.modelo + "é R$" + autoluxo1.quantocusta());
        
        
    
        
    }
    
}
