package bancodedados;

import java.sql.*;
import java.util.*;
import javax.swing.JOptionPane;

public class Transacoes {
    
    public void inserir(Produto prod){
        Connection con = Conexao.conecta();
        PreparedStatement stmt = null;
        try {   
            stmt = con.prepareStatement("insert into produtos "
                    + "(nome, qtd_estoque, preco) values (?,?,?)");
            stmt.setInt(2, prod.getQtd());
            stmt.setString(1, prod.getNome());
            stmt.setFloat(3, prod.getPreco());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, prod.getNome());
        } catch (SQLException e) {
            System.out.println("Falha ao inserir registro" + e);
        }finally{
            Conexao.fechaConexao(con, stmt);
        }
    }
    public ArrayList<Produto> consultar (String prod){        
        Connection con = Conexao.conecta(); //banco
        PreparedStatement stmt = null; //tabela
        ResultSet rs = null;//registros da tabela    
        ArrayList<Produto> linha = new ArrayList<>();
        try {
            stmt = con.prepareStatement("select * from produtos where nome='"+prod +"'");
            rs = stmt.executeQuery();
            if (rs.next()){
                Produto obj = new Produto();
                obj.setNome(rs.getString("nome"));
                obj.setPreco(rs.getFloat("preco"));
                obj.setQtd(rs.getInt("qtd_estoque"));
                linha.add(obj);    
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Falha ao consultar registro\n" + e);        
        } finally {
            Conexao.fechaConexao(con, stmt, rs);
        }
        return linha; 
    }
    public int deletarProduto(String nome) {
    Connection con = Conexao.conecta();
    PreparedStatement stmt = null;
    int rs = 0;
    try {
        stmt = con.prepareStatement("DELETE FROM produtos WHERE nome = '"+ nome + "'");
        
        
        rs=stmt.executeUpdate();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Falha ao deletar produto\n" + e);
    } finally {
        Conexao.fechaConexao(con, stmt);
    }
    return rs;
    }
    public void alterar(Produto prod, String nome){
        Connection con = Conexao.conecta();
        PreparedStatement stmt = null;
        try {   
            stmt = con.prepareStatement("update produtos set qtd_estoque = ?, preco = ? where nome = ?");
            stmt.setInt(1, prod.getQtd());
            stmt.setString(3, prod.getNome());
            stmt.setFloat(2, prod.getPreco());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, prod.getNome() + "alterada com sucesso");
        } catch (SQLException e) {
            System.out.println("Falha ao inserir registro" + e);
        }finally{
            Conexao.fechaConexao(con, stmt);
        }
}
}
