package aplicacao;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TelaCadastro extends javax.swing.JFrame {

    int id;
    ArrayList<Tarefa> listaTask = new ArrayList<>();//lista 
    DefaultTableModel dtm;//tabela

    public TelaCadastro() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtdescr = new javax.swing.JTextArea();
        txttitulo = new javax.swing.JTextField();
        txtdatalimite = new javax.swing.JFormattedTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cmbnivel = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbltask = new javax.swing.JTable();
        btadd = new javax.swing.JButton();
        btdel = new javax.swing.JButton();
        btedit = new javax.swing.JButton();
        btcleanr = new javax.swing.JButton();
        btclose = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("CADASTRO DE TAREFA");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(new javax.swing.border.MatteBorder(null));

        jLabel1.setText("TITULO");

        jLabel2.setText("DATA LIMITE");

        txtdescr.setColumns(20);
        txtdescr.setRows(5);
        jScrollPane2.setViewportView(txtdescr);

        txttitulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttituloActionPerformed(evt);
            }
        });

        jLabel3.setText("DESCRIÇÃO");

        jLabel4.setText("NiVEL");

        cmbnivel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FÁCIL", "INTERMEDIÁRIO", "DÍFICIL" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtdatalimite, javax.swing.GroupLayout.PREFERRED_SIZE, 347, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(cmbnivel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txttitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 648, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(33, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txttitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtdatalimite, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(cmbnivel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel3)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        tbltask.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "TÍTULO", "DESCRIÇÃO", "NÍVEL", "DATA LIMITE"
            }
        ));
        tbltask.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbltaskMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbltask);

        btadd.setText("ADD");
        btadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btaddActionPerformed(evt);
            }
        });

        btdel.setText("DEL");
        btdel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btdelActionPerformed(evt);
            }
        });

        btedit.setText("EDIT");
        btedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bteditActionPerformed(evt);
            }
        });

        btcleanr.setText("CLEANR");
        btcleanr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btcleanrActionPerformed(evt);
            }
        });

        btclose.setText("CLOSE");
        btclose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btcloseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btadd)
                        .addGap(98, 98, 98)
                        .addComponent(btdel)
                        .addGap(131, 131, 131)
                        .addComponent(btedit)
                        .addGap(111, 111, 111)
                        .addComponent(btcleanr)
                        .addGap(121, 121, 121)
                        .addComponent(btclose)
                        .addGap(58, 58, 58))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(47, 47, 47))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btadd)
                    .addComponent(btdel)
                    .addComponent(btedit)
                    .addComponent(btcleanr)
                    .addComponent(btclose))
                .addGap(62, 62, 62))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btaddActionPerformed
        //String tit, dta, niv, desc; outra maneira de declarar string 
        //capturando as informações digitadas pelo usuário 
        String tit = txttitulo.getText();
        String dta = txtdatalimite.getText();
        int niv = cmbnivel.getSelectedIndex();
        String desc = txtdescr.getText();

        //criando a tarefa (objeto tarefa)
        Tarefa t = new Tarefa(tit, desc, dta, ++id, niv);
        //criando o objeto operacoes
        Operacoes op = new Operacoes();

        if (op.adicionar(t, listaTask)) {
            // JOptionPane.showMessageDialog(rootPane, "SUCESSO!!!");
            showtask();
            limpar();
        } else {
            JOptionPane.showMessageDialog(rootPane, "SUCESSO!!!");
        }


    }//GEN-LAST:event_btaddActionPerformed

    private void txttituloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttituloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txttituloActionPerformed

    private void btcloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btcloseActionPerformed
        System.exit(0); //comando fechar programa


    }//GEN-LAST:event_btcloseActionPerformed

    private void btcleanrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btcleanrActionPerformed
        limpar();
    }//GEN-LAST:event_btcleanrActionPerformed

    private void tbltaskMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbltaskMouseClicked
        //getSelectedRow()  seleciona alinha que o usuário clicou 
        if (tbltask.getSelectedRow() != -1) {
            txttitulo.setText(tbltask.getValueAt(tbltask.getSelectedRow(), 1).toString());
            txtdescr.setText(tbltask.getValueAt(tbltask.getSelectedRow(), 2).toString());
            cmbnivel.setSelectedIndex((int) tbltask.getValueAt(tbltask.getSelectedRow(), 3));
            txtdatalimite.setText(tbltask.getValueAt(tbltask.getSelectedRow(), 4).toString());
        }

    }//GEN-LAST:event_tbltaskMouseClicked

    private void btdelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btdelActionPerformed
        if (tbltask.getSelectedRow() != -1) {
            int idTarefa = (int) tbltask.getValueAt(tbltask.getSelectedRow(), 0);
            Operacoes op = new Operacoes();

            if (op.excluirTask(idTarefa, listaTask)) {
                dtm.removeRow(tbltask.getSelectedRow());
            } else {
                JOptionPane.showMessageDialog(rootPane, "Erro ao excluir tarefa!!!");
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "É preciso clicar sobre uma tarefa!");
        }

        showtask();
        limpar();


    }//GEN-LAST:event_btdelActionPerformed

    private void bteditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bteditActionPerformed
        if (tbltask.getSelectedRow() != -1) {
            String tit = txttitulo.getText();
            int niv = cmbnivel.getSelectedIndex();
            String dta = txtdatalimite.getText();
            String desc = txtdescr.getText();
            int num = (int) tbltask.getValueAt(tbltask.getSelectedRow(), 0);
            
            //criando a tarefa (objeto tarefa)
            Tarefa t = new Tarefa(tit, desc, dta,num, niv);
            //criando o objeto operacoes
            Operacoes op = new Operacoes();

            if (op.editar(t,num, listaTask)) {
                // JOptionPane.showMessageDialog(rootPane, "SUCESSO!!!");
                showtask();
                limpar();

            }

        }


    }//GEN-LAST:event_bteditActionPerformed
    private void limpar() {
        txttitulo.setText("");
        txtdatalimite.setText("");
        txtdescr.setText("");
        cmbnivel.setSelectedIndex(0);
    }

    //metodo  mostrar tarefa,     
    private void showtask() {
        dtm = (DefaultTableModel) tbltask.getModel();
        dtm.setNumRows(0);
        for (int i = 0; i < listaTask.size(); i++) {
            dtm.addRow(new Object[]{
                listaTask.get(i).getId(),
                listaTask.get(i).getTitulo(),
                listaTask.get(i).getDescricao(),
                listaTask.get(i).getNivel(),
                listaTask.get(i).getDatalimite()

            });
        }
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new TelaCadastro().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btadd;
    private javax.swing.JButton btcleanr;
    private javax.swing.JButton btclose;
    private javax.swing.JButton btdel;
    private javax.swing.JButton btedit;
    private javax.swing.JComboBox<String> cmbnivel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tbltask;
    private javax.swing.JFormattedTextField txtdatalimite;
    private javax.swing.JTextArea txtdescr;
    private javax.swing.JTextField txttitulo;
    // End of variables declaration//GEN-END:variables
}
