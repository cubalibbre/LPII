package Concessionaria;

public class Seguros implements Vendavel {
    String nomeSeguro;
    double mensalidade;

    Seguros(String seguro_simples, int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String getdescricao() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    @Override
    public double qntCusta() {
        System.out.println("O seguro " + nomeSeguro + " custa anualmente:");
        return (12 * mensalidade);
    }
}
