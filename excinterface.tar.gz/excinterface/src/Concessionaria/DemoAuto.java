package Concessionaria;


public class DemoAuto {


    public static void main(String[] args) {
        Automovel auto1 = new Automovel("Fusca", "azul", 1);
        System.out.println("O preço do " + auto1.modelo + " é: R$"+ auto1.qntCusta());
        
        AutomovelBasico auto2 = new AutomovelBasico("Gol", "Preto", 2);
        System.out.println("O preço do " + auto2.modelo + " é: R$"+ auto2.qntCusta());
        
        AutomovelBasico auto3 = new AutomovelBasico(true, false, false, "Palio", "verde", 1);
        System.out.println("O preço do " + auto3.modelo + " " + auto3.cor + " é: R$"+ auto3.qntCusta());
        
        AutomovelLuxo auto4 = new AutomovelLuxo(true, true, true, true, true, true, "Corolla", "prata", 3);
        System.out.println("O preço do " + auto4.modelo + " " + auto4.cor + " é: R$"+ auto4.qntCusta());
        
        Seguros segurobasico = new Seguros("seguro simples", 100);
    }
    
}
