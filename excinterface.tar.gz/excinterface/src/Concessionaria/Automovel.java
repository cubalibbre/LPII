package Concessionaria;


public class Automovel implements Vendavel {
    String modelo, cor;
    int combustivel;

    public Automovel(String modelo, String cor, int combustivel) {
        this.modelo = modelo;
        this.cor = cor;
        this.combustivel = combustivel;
    }
    
    @Override
    public double qntCusta(){
        double prc = 0;
        switch (combustivel) {
            case 1:
                prc=20000;
                break;
            case 2:
                prc=19520;
                break;
            case 3:
                prc=25000;
                break;
            case 4:
                prc=22000;
            default:
                break;
        }
        return prc;

}

    @Override
    public String getdescricao() {
        return("É um" + modelo + "" + cor);
    }
    
}
//tp 1 gasolina = 20000 , tp 2 alcool = 19520, tp 3 diesel = 25000, tp 4 gás = 22000
