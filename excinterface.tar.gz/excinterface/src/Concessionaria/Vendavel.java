package Concessionaria;

public interface Vendavel{
    String getdescricao();
    
    double qntCusta();
}
