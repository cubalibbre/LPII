package Concessionaria;

public class AutomovelBasico extends Automovel{
    boolean retrovisorPassageiro, 
            limpadorTraseiro, 
            radio;

    public AutomovelBasico(boolean retrovisorPassageiro, boolean limpadorTraseiro, boolean radio, String modelo, String cor, int combustivel) {
        super(modelo, cor, combustivel);
        this.retrovisorPassageiro = retrovisorPassageiro;
        this.limpadorTraseiro = limpadorTraseiro;
        this.radio = radio;
    }

    public AutomovelBasico(String modelo, String cor, int combustivel) {
        super(modelo, cor, combustivel);
        retrovisorPassageiro = true;
        radio = true;
        limpadorTraseiro = true;
    }
    
    @Override
    public double qntCusta(){
        double preco = super.qntCusta();
        if(retrovisorPassageiro){
            preco+=280;
        }if(limpadorTraseiro){
            preco+=190;
        }if(radio){
            preco+=320;
        }
        return preco;
    }

    
    }
    
