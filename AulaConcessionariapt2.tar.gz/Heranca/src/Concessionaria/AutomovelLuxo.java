
package Concessionaria;

public class AutomovelLuxo extends AutomovelBasico {
    
    boolean direcaoHidraulica,
            cambioAutomatico,
            travasEletricas;

    public AutomovelLuxo(boolean direcaoHidraulica, boolean cambioAutomatico, 
            boolean travasEletricas, boolean retrovisorPassageiro, boolean limpadorTraseiro, 
            boolean radio, String modelo, String cor, int combustivel) {
        super(retrovisorPassageiro, limpadorTraseiro, radio, modelo, cor, combustivel);
        this.direcaoHidraulica = true;
        this.cambioAutomatico = true;
        this.travasEletricas = true;
    }

    public AutomovelLuxo(boolean direcaoHidraulica, boolean cambioAutomatico, 
            boolean travasEletricas, String modelo, String cor, int combustivel) {
        super(modelo, cor, combustivel);
        this.direcaoHidraulica = direcaoHidraulica;
        this.cambioAutomatico = cambioAutomatico;
        this.travasEletricas = travasEletricas;
    }

    @Override
    public double qntCusta(){
       double preco = super.qntCusta();
        if(direcaoHidraulica){
            preco+=3340;
        }if(cambioAutomatico){
            preco+=1650;
        }if(travasEletricas){
            preco+=2190;
        }
       
       
       return preco; 
    }

    
}
