package batepapo;

import java.net.*;
import java.io.*;

public class Cliente extends javax.swing.JFrame {

    ServerSocket ss;
    Socket cliente;
    DataInputStream in;
    DataOutputStream out;

    public Cliente() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        CLICOR = new javax.swing.JPanel();
        btenviarcli = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        areacli = new javax.swing.JTextArea();
        txtmsgcli = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        CLICOR.setBackground(java.awt.Color.lightGray);
        CLICOR.setForeground(java.awt.Color.lightGray);

        btenviarcli.setIcon(new javax.swing.ImageIcon(getClass().getResource("/batepapo/Bootstrap-send-fill-icon.png"))); // NOI18N
        btenviarcli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btenviarcliActionPerformed(evt);
            }
        });

        areacli.setColumns(20);
        areacli.setRows(5);
        jScrollPane1.setViewportView(areacli);

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Noto Sans", 1, 24)); // NOI18N
        jLabel1.setText("C L I E N T E");

        javax.swing.GroupLayout CLICORLayout = new javax.swing.GroupLayout(CLICOR);
        CLICOR.setLayout(CLICORLayout);
        CLICORLayout.setHorizontalGroup(
            CLICORLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CLICORLayout.createSequentialGroup()
                .addGroup(CLICORLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CLICORLayout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 496, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(CLICORLayout.createSequentialGroup()
                        .addGap(239, 239, 239)
                        .addComponent(jLabel1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CLICORLayout.createSequentialGroup()
                .addContainerGap(76, Short.MAX_VALUE)
                .addComponent(txtmsgcli, javax.swing.GroupLayout.PREFERRED_SIZE, 413, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btenviarcli, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70))
        );
        CLICORLayout.setVerticalGroup(
            CLICORLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CLICORLayout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jLabel1)
                .addGap(38, 38, 38)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addGroup(CLICORLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CLICORLayout.createSequentialGroup()
                        .addComponent(btenviarcli)
                        .addGap(26, 26, 26))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CLICORLayout.createSequentialGroup()
                        .addComponent(txtmsgcli, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(CLICOR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(CLICOR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void InciarCliente() {
        try {
            cliente = new Socket("127.0.0.1", 8080);
            while (true) {
                in = new DataInputStream(cliente.getInputStream());
                out = new DataOutputStream(cliente.getOutputStream());
                areacli.append(in.readUTF() + "\n");

            }
        } catch (Exception e) {
            System.out.println("Falha" + e);
        }

    }


    private void btenviarcliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btenviarcliActionPerformed
        try {
            out.writeUTF(txtmsgcli.getText());
            areacli.append(txtmsgcli.getText());
            txtmsgcli.setText("" + "\n");

        } catch (Exception e) {
            areacli.append("Falha" + e + "\n");
        }
    }//GEN-LAST:event_btenviarcliActionPerformed

    public static void main(String args[]) {
       Cliente tc = new Cliente();
       tc.setVisible(true);
       tc.InciarCliente();

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel CLICOR;
    private javax.swing.JTextArea areacli;
    private javax.swing.JButton btenviarcli;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtmsgcli;
    // End of variables declaration//GEN-END:variables
}
