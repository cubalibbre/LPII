

package batepapo;
import java.net.*;
import java.io.*;



public class Servidor extends javax.swing.JFrame {
    
    ServerSocket ss;
    Socket cliente;
    DataInputStream in;
    DataOutputStream out;
    
   
    public Servidor() {
        initComponents();
        areaser.setEditable(false);
        
        
    }
    @SuppressWarnings("unchecked")
    
    public void executar (){
        
            try {
                ss = new ServerSocket(8080);
                areaser.append("Servidor está executando na porta 8080" + "\n");
                cliente = ss.accept();
               
                while (true){
                    in = new DataInputStream(cliente.getInputStream());
                    out = new DataOutputStream(cliente.getOutputStream());
                    areaser.append(in.readUTF() + "\n");
                            
                }
                
            } catch (IOException e) {
                areaser.append("falha:" + e + "\n");
            }
    }
    
    public static void main (String args[]){
        Servidor obj = new Servidor ();
        obj.setVisible(true);
        obj.executar();
        
    }
    
    
    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        SERVCOR = new javax.swing.JPanel();
        btenviarserv = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaser = new javax.swing.JTextArea();
        txtmsgserv = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        SERVCOR.setBackground(java.awt.Color.lightGray);

        btenviarserv.setIcon(new javax.swing.ImageIcon(getClass().getResource("/batepapo/Bootstrap-send-fill-icon.png"))); // NOI18N
        btenviarserv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btenviarservActionPerformed(evt);
            }
        });

        areaser.setColumns(20);
        areaser.setRows(5);
        jScrollPane1.setViewportView(areaser);

        txtmsgserv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtmsgservActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Noto Sans", 1, 24)); // NOI18N
        jLabel1.setText("S E R V I D O R");

        javax.swing.GroupLayout SERVCORLayout = new javax.swing.GroupLayout(SERVCOR);
        SERVCOR.setLayout(SERVCORLayout);
        SERVCORLayout.setHorizontalGroup(
            SERVCORLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SERVCORLayout.createSequentialGroup()
                .addGroup(SERVCORLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SERVCORLayout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addGroup(SERVCORLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(SERVCORLayout.createSequentialGroup()
                                .addComponent(txtmsgserv, javax.swing.GroupLayout.PREFERRED_SIZE, 433, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btenviarserv, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 511, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(SERVCORLayout.createSequentialGroup()
                        .addGap(226, 226, 226)
                        .addComponent(jLabel1)))
                .addContainerGap(63, Short.MAX_VALUE))
        );
        SERVCORLayout.setVerticalGroup(
            SERVCORLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SERVCORLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jLabel1)
                .addGap(36, 36, 36)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addGroup(SERVCORLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btenviarserv)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SERVCORLayout.createSequentialGroup()
                        .addComponent(txtmsgserv, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)))
                .addGap(29, 29, 29))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SERVCOR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SERVCOR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtmsgservActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtmsgservActionPerformed
     
    }//GEN-LAST:event_txtmsgservActionPerformed

    private void btenviarservActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btenviarservActionPerformed
        try {
            out.writeUTF(txtmsgserv.getText());
            areaser.append(txtmsgserv.getText());
            txtmsgserv.setText("");
            
        } catch (Exception e) {
            areaser.append("Falha" + e + "\n");
        }
    }//GEN-LAST:event_btenviarservActionPerformed

   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel SERVCOR;
    private javax.swing.JTextArea areaser;
    private javax.swing.JButton btenviarserv;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtmsgserv;
    // End of variables declaration//GEN-END:variables
}
