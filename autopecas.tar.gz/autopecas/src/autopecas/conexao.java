
package autopecas;
import java.sql.*;

public class conexao {
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/autopecas";
    private static final String USER = "root";//usuario do BD
    private static final String SENHA = "toor";//senha do BD
    //método que obtem a conexao com o BD: servicosDB
    public static Connection conecta(){
        Connection con = null;        
        try {
            Class.forName(DRIVER);//carregando o driver do BD
            con = DriverManager.getConnection(URL, USER, SENHA);
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Erro na conexão " + e);
        }        
        return con;
    }
    //método q fecha a conexão com o BD
    public static void fechaConexao(Connection con){
        try {
            if (con != null){
                con.close();
            }
        } catch (SQLException e) {
            System.out.println("Ao erro ao fechar conexão" + e);
        }        
    }    
    //método q fecha a conexão com o BD e 'tabela'
    public static void fechaConexao(Connection con,
             PreparedStatement stmt){
        fechaConexao(con) ;
        try {
            if (stmt != null){
                stmt.close();
            }
        } catch (SQLException e) {
            System.out.println("Ao erro ao fechar conexão" + e);
        }        
    }    
   
    //método q fecha a conexão com o BD, 'tabela' e 'registro'
    public static void fechaConexao(Connection con,
            PreparedStatement stmt, ResultSet rs){
        fechaConexao(con, stmt) ;
        try {
            if (rs != null){
                rs.close();
            }
        } catch (SQLException e) {
            System.out.println("Ao erro ao fechar conexão" + e);
        }        
    }
     
}
    
    

