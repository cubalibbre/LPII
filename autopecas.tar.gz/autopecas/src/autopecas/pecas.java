
package autopecas;


public class pecas {
     private int codigo; 
     private String nome; 
     private Float preco; 

    public pecas() {
    }
   

    public pecas(int codigo, String nome, Float preco, int quant) {
        this.codigo = codigo;
        this.nome = nome;
        this.preco = preco;
        this.quant = quant;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Float getPreco() {
        return preco;
    }

    public void setPreco(Float preco) {
        this.preco = preco;
    }

    public int getQuant() {
        return quant;
    }

    public void setQuant(int quant) {
        this.quant = quant;
    }
     private int quant; 
}
