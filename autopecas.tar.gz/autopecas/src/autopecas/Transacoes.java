
package autopecas;
import java.sql.*;
import java.util.*;
import javax.swing.JOptionPane;



public class Transacoes {
    public ArrayList<pecas> consultar (int nos){        
        Connection con = conexao.conecta(); //banco
        PreparedStatement stmt = null; //tabela
        ResultSet rs = null;//registros da tabela
        
        ArrayList<pecas> linha = new ArrayList<>();
        try {
            stmt = con.prepareStatement("select * from ordem_servico where num_os="+nos);
            rs = stmt.executeQuery();
            if (rs.next()){
                pecas os = new  pecas();  
                
                os.setCodigo(rs.getInt("codigo"));
                os.setNome(rs.getString("nome"));
                os.setPreco(rs.getFloat("preco"));
                os.setQuant(rs.getInt("quant"));
                
                linha.add(os);    
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Falha ao consultar registro\n" + e);        
        } finally {
            conexao.fechaConexao(con, stmt, rs);
        }
        return linha;
    }
   
    public void inserir(pecas os){        
        Connection con = conexao.conecta();
        PreparedStatement stmt = null;
        try {
            stmt = con.prepareStatement("insert into ordem_servico "
                    + "(num_os, descricao, tipo) values (?,?,?)");
           
            stmt.setInt(1, os.getCodigo());
            stmt.setString(2, os.getNome());
            stmt.setFloat(3, os.getPreco());
            stmt.setInt(1, os.getQuant());
           
            stmt.executeUpdate();
           
            JOptionPane.showMessageDialog(null,
                    os.getCodigo()+ " inserida com sucesso!");          
        } catch (SQLException e) {
            System.out.println("Falha ao inserir registro" + e);
        }finally{
            conexao.fechaConexao(con, stmt);
        }
       
    }//fechamento do método
   
    //DELETE
    //...
   
    //ATUALIZAÇÃO: UPDATE
    //...
}//fechamento da classe

