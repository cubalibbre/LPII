package dante;

import java.util.Scanner;

public class Dante {
    //metodo principal
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        //classe Scanner possui um metodo para fazer input de informação
        
        
        System.out.println("Digite seu nome:  ");
        String nome = entrada.next();
        
                
        //saída padrão
        System.out.println("O proximo ta na linha de baixo");
        //print line quebra linha, print nao
        System.out.print("O proximo ta do lado:  ");
        System.out.println("O proximo ta em baixo");
        
        /* O tipo da variavel deve ser especificado SEMPRE
            os tipos "primitivos" para números inteiros são:
            BYTE
            SHORT
            INT
            LONG
        
        */
       
        System.out.print(nome + ", insira o valor de n1: ");
        int n1 = entrada.nextInt();
        //nextInt é o método da classe Scanner para fazer leitura de entrada
        System.out.print(nome + ", insira o valor de n2: ");
        int n2 = entrada.nextInt();
        int n3 = n1+n2;
        // para printar 5 + -7 = -2
        // o + no print funciona como a virgula em python, para separar o que sera printado
        System.out.println(n1 + " + " + n2 + " = " + n3);
        

        
    } //fechamento do METODO (main)
    
} //fechamento da classe (Dante)
