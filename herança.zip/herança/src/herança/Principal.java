
package herança;

import java.util.Scanner;



public class Principal {

   
    public static void main(String[] args) {
        
      Scanner sc = new Scanner (System.in);
      
        System.out.println("digite o nome da pessoa:");
        String nomeP = sc.next();
        
        
        System.out.println("digite o cpf da pessoa");
        String cpfP = sc.next();
        
        
         Pessoa p1 = new Pessoa(nomeP, cpfP);
        System.out.println(p1.toString());
        
        
           
        System.out.println("digite o nome do funcionario");
        String nomeF = sc.next();
        
        System.out.println("digite o cpf do funcionario");
        String cpfF = sc.next();
        
        System.out.println("digite o salario do funcionario");
        double salarioF = sc.nextDouble();
        
         Funcionario f1 = new Funcionario(salarioF, nomeF, cpfF);
       System.out.println(f1.toString());
    }
    
}
