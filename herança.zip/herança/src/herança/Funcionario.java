
package herança;

//fucionario é a super class(classe de BASE) DE PESSOA
public class Funcionario extends Pessoa {
    
    private double salario;

    public Funcionario(double salario, String nome, String cpf) {
        super(nome, cpf);
        this.salario = salario;
        
    }

    @Override
    public String toString() {
        String dadosdePessoa = super.toString();
        return dadosdePessoa + "Funcionario{" + "salario=" + salario + '}';
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
}
