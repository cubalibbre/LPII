
package appmsg;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {

   
    public static void main(String[] args) {
      
        try {
            ServerSocket servidor = new ServerSocket(8080);
            System.out.println("Servidor executando na porta 8080");
            Socket cliente = servidor.accept();
            
            DataInputStream in = new DataInputStream(cliente.getInputStream());
            
            DataOutputStream out = new DataOutputStream (cliente.getOutputStream());
            
            int valor = in.readInt() ;
            System.out.println("Recebidos" + valor);
            out.writeInt(valor * 2 );
            
            in.close(); out.close();
            cliente.close(); servidor.close();
            
            
            
        } catch (Exception e) {
            System.out.println("Exceção" + e);
        }
        
        
        
        
    }
    
}
