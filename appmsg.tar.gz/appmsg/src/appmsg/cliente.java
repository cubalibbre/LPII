
package appmsg;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

public class cliente {
    public static void main(String[] args) {
      
        try {
            
            Socket cliente = new Socket("localhost", 8080);
            DataInputStream in = new DataInputStream(cliente.getInputStream());
            
            DataOutputStream out = new DataOutputStream(cliente.getOutputStream());
            
            
            out.write(1000);
            System.out.println("Veio do servido "  + in.readInt());
            
            in.close();
            out.close();
                
               
        } catch (Exception e) {
            System.out.println("Exceção" + e );
        }
        
 
    }
}
