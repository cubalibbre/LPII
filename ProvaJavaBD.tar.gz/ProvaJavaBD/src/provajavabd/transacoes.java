
package provajavabd;
import java.sql.*;


public class transacoes {
    
    public void inserir (OrdemServico os){
        Connection con = conexao.conecta();
        PreparedStatement stmt = null;
        try {
            stmt = con.prepareStatement(" insert into ordem_servico (num_os , descricao, tipo) "
                    + "values (?,?,?);");
            //...
            //...
        } catch (SQLException e) {
            System.out.println("Falha ao inserir registro" + e);
        }
        
    }
    
}
