/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jeanprograma;

import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class Jeanprograma {

    /**
     * @param args the command line arguments
     */
    //METODO PRINCIPAL
    public static void main(String[] args) {
        
        //classe Scanner é o metodo de input ou seja de entrada
        //entrada é o objeto
        Scanner entrada = new Scanner(System.in);
        
        //SAIDA DO NOME
        System.out.println("DIGITE SEU NOME:");
        //String para colocar o nome
        String nome = entrada.next();
        System.out.println("seu nome é" + nome );
        
      
        
        //SAIDA PADRÃO
        //System.out.print("OLÁ MUNDO. JEAN FREITAS SANTOS");
        
        //SAIDA EM UMA LINHA
        System.out.println("ENTRE COM O VALOR DE N1:");
         //ENTRADA NO TECLADO
        int n1 = entrada.nextInt();
        
        //SAIDA EM UMA LINHA
        System.out.println("ENTRE COM O VALOR DE N2:");
        //ENTRADA NO TECLADO
        int n2 = entrada.nextInt();
        int resultado = n1 + n2;
        
        //SAIDA DE SOMANDO
        //o + no print funciona como a virgula em python, para separar o que sera printado
        System.out.println(n1 + "+" + n2 + "=" + resultado);
        
        
        
        
        
        
        
        
        
        
        
      
        /*TIPO DE VARIAVEL É PARA SER ESPECIFICADO:
        SÃO ELAS 
        BYTE
        SHORT
        INT 
        LONG
        */
        
        //int n1 = 5;
        //int n2 = -7;
        //para printar 5 + -7 = -2
        //o + no print funciona como a virgula em python, para separar o que sera printado
    //System.out.println(n1 + "+" + n2 + "=" + (n1 + n2));
    
       
       
        
        
    }//FECHAMENTO DO METODO MAIN
    
}//FECHAR CLASSE
