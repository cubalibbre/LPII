/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula02;

/**
 *
 * @author aluno
 */
public class Operaçoes {
    
    public int somaSimplesOP(int n1, int n2){
        
        int soma = 0;
        
        soma = n1 + n2;
        
        return soma;
}
    
    public int multSimplesOP(int n1, int n2){
        
        int mult = 0;
        
        mult = n1 * n2;
        
        return mult;
}
}
