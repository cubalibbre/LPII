package aula02;

import java.util.Scanner;

public class Aula02 {


    public static void main(String[] args) {
        
//        System.out.println("Projeto Aula 2");
        //criando o objeto in do tipo scanner
        Scanner in = new Scanner (System.in);
//        System.out.println("Insira o nome: ");
//        String nome = in.next();
//        System.out.println("Insira o ano de nascimento: ");
//        int ano = in.nextInt();
//        System.out.println(nome + "sua idade em 2025 será:  " + 
//                (2025 -ano));
        Operaçoes op = new Operaçoes ();
        
        int x = in.nextInt();
        int y = in.nextInt();
        
        System.out.println(x + " X " + y + " = " + (op.multSimplesOP(x, y)));
        
    
    }
        
    private static int somaSimples(int n1, int n2){
        
        int soma = 0;
        
        soma = n1 + n2;
        
        return soma;
        
    }
    

}
